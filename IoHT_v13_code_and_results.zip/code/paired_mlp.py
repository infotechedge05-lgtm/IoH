"""Paired comparison of the main VAE-attention model against two supervised MLPs, per seed.

Usage:  python3 -I paired_mlp.py ecu|iomt|wustl|wustl_net
Output: /home/claude/final/paired_<dataset>.json

For each split and seed:
  * VAE-attention (main, H=32, L=8, beta=1) trained on benign training rows only;
    threshold-free ROC-AUC from reconstruction error.
  * MLP (default):        hidden (64, 32), max_iter 200, no_change 10.
  * MLP (longer schedule): hidden (128, 64), alpha 1e-4, max_iter 300, no_change 20.
    Fixed in advance; it is not selected on test data.
  * Paired bootstrap: 500 resamples of the test rows, the same row indices for every
    model. The reported difference is AUC(MLP) - AUC(VAE); the interval is the 2.5-97.5
    percentile range of the bootstrap differences.

Test rows, scaling and the 300k IoMT training subsample match baselines_all.py,
baselines_wustl.py and mlp_baseline.py.
"""
import sys, json, time
DS = sys.argv[1]
import numpy as np
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import train_test_split

if DS in ('ecu', 'iomt'):
    sys.path.insert(0, '/home/claude/final')
    import baselines_all as M
else:
    sys.path.insert(0, '/home/claude/wustl/code')
    import baselines_wustl as M

T0 = time.time()
def log(*a): print(f'[{time.time()-T0:6.0f}s]', *a, flush=True)

SEEDS = [0, 1, 2]
B = 500
OUT = f'/home/claude/final/paired_{DS}.json'
CONFIGS = {
    'MLP default': dict(hidden_layer_sizes=(64, 32), max_iter=200, n_iter_no_change=10),
    'MLP longer schedule': dict(hidden_layer_sizes=(128, 64), alpha=1e-4, max_iter=300, n_iter_no_change=20),
}

def make_mlp(seed, cfg):
    return MLPClassifier(activation='relu', solver='adam', learning_rate_init=1e-3,
                         batch_size=256, early_stopping=True, validation_fraction=0.1,
                         random_state=seed, **cfg)

def paired_auc_diff(yt, s_vae, s_mlp, rng):
    """AUC(MLP) - AUC(VAE) on the full test set, with a paired bootstrap interval."""
    n = len(yt)
    diffs = np.empty(B)
    for i in range(B):
        b = rng.integers(0, n, n)
        diffs[i] = roc_auc_score(yt[b], s_mlp[b]) - roc_auc_score(yt[b], s_vae[b])
    point = roc_auc_score(yt, s_mlp) - roc_auc_score(yt, s_vae)
    ci = [float(np.percentile(diffs, 2.5)), float(np.percentile(diffs, 97.5))]
    return float(point), ci

splits = M.load_splits()
res = {'dataset': DS, 'bootstrap_B': B, 'splits': {}}
for name, (Xtr, ytr, Xte, yte) in splits.items():
    Xb = Xtr[ytr == 0]                                   # VAE: benign training rows only
    Xm, ym = Xtr, ytr                                    # MLP: labelled training rows
    if len(ytr) > 300_000:
        idx, _ = train_test_split(np.arange(len(ytr)), train_size=300_000, stratify=ytr, random_state=0)
        Xm, ym = Xtr[idx], ytr[idx]
    per = {}
    for seed in SEEDS:
        P = M.train(Xb, True, 32, 8, 1.0, False, seed)
        e_vae, _ = M.score_ae(P, Xb, Xte, True)
        row = {'VAE-attention (main)': {'roc_auc': float(roc_auc_score(yte, e_vae))}}
        log(f'{name} seed {seed}: VAE AUC={row["VAE-attention (main)"]["roc_auc"]:.4f}')
        for mname, cfg in CONFIGS.items():
            clf = make_mlp(seed, cfg).fit(Xm, ym)
            p = clf.predict_proba(Xte)[:, 1]
            pred = (p > 0.5).astype(int)
            d, ci = paired_auc_diff(yte, e_vae, p, np.random.default_rng(1000 + seed))
            row[mname] = dict(
                roc_auc=float(roc_auc_score(yte, p)),
                accuracy=float((pred == yte).mean()),
                iterations=int(clf.n_iter_),
                delta_auc_vs_VAE=d,
                delta_auc_ci=ci,
                ci_excludes_zero=bool(ci[0] > 0 or ci[1] < 0))
            log(f'{name} seed {seed} {mname}: AUC={row[mname]["roc_auc"]:.4f} '
                f'dAUC={d:+.4f} CI=[{ci[0]:+.4f},{ci[1]:+.4f}] epochs={clf.n_iter_}')
        per[f'seed{seed}'] = row
        res['splits'][name] = per
        json.dump(res, open(OUT, 'w'), indent=2)

# summary across seeds
for name, per in res['splits'].items():
    for mname in CONFIGS:
        d = np.array([per[s][mname]['delta_auc_vs_VAE'] for s in per])
        ex = sum(per[s][mname]['ci_excludes_zero'] for s in per)
        log(f'SUMMARY {name} | {mname}: mean dAUC={d.mean():+.4f} per-seed={np.round(d,4).tolist()} CI excludes 0 in {ex}/{len(per)} seeds')
log('saved', OUT)
