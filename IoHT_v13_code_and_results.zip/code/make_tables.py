"""Build markdown tables for the manuscript from the saved JSON results (no hand-copied numbers)."""
import json, numpy as np

ECU = json.load(open('/home/claude/final/baselines_ecu.json'))
IOMT = json.load(open('/home/claude/final/baselines_iomt.json'))
SENS = json.load(open('/home/claude/novelty/feature_sensitivity_ecu.json'))
ORDER = ['VAE-attention (main)', 'VAE-no-attention', 'VAE-attention (tuned)',
         'AE-attention (deterministic, tuned)', 'Isolation Forest', 'One-Class SVM',
         'Random Forest (supervised)']
LABEL = {'VAE-attention (main)': 'VAE + attention (main)',
         'VAE-no-attention': 'VAE, no attention',
         'VAE-attention (tuned)': 'VAE + attention (tuned on benign validation)',
         'AE-attention (deterministic, tuned)': 'Deterministic AE, β = 0 (tuned)',
         'Isolation Forest': 'Isolation Forest',
         'One-Class SVM': 'One-Class SVM',
         'Random Forest (supervised)': 'Random Forest (supervised)'}


def rows_for(block):
    ps = block['per_seed']
    seeds = list(ps.keys())
    out, stats = [], {}
    for m in ORDER:
        f1 = [ps[s][m]['f1'] * 100 for s in seeds]
        auc = [ps[s][m]['roc_auc'] for s in seeds]
        if m == 'VAE-attention (main)':
            d_txt, sig_txt = '—', '—'
            d_mean = 0.0
        else:
            d = [ps[s][m]['auc_diff_vs_VAE_attention']['point'] for s in seeds]
            ci = [ps[s][m]['auc_diff_vs_VAE_attention']['ci'] for s in seeds]
            sig = sum(1 for lo, hi in ci if lo > 0 or hi < 0)
            d_mean = float(np.mean(d))
            d_txt = f'{d_mean:+.4f}'
            sig_txt = f'{sig}/{len(seeds)}'
        stats[m] = dict(f1=float(np.mean(f1)), auc=float(np.mean(auc)), d=d_mean)
        out.append(f'| {LABEL[m]} | {np.mean(f1):.2f} ({min(f1):.2f}–{max(f1):.2f}) | '
                   f'{np.mean(auc):.4f} ({min(auc):.4f}–{max(auc):.4f}) | {d_txt} | {sig_txt} |')
    return out, stats


HDR = ('| Model | F1 (%) mean (range) | ROC-AUC mean (range) | ΔAUC (VAE − model) | '
       'Seeds where 95% CI excludes 0 |\n|---|---|---|---|---|')


def sens_table():
    lab = {'all_12_features': 'None (all 12 features)',
           'no_timing_features': 'Timing: log Δt, packets in past 1 s, ICMP in past 1 s',
           'no_protocol_onehot': 'Protocol indicators (6)',
           'no_link_layer_flags': 'Broadcast and MAC-layer flags (2)',
           'no_length': 'Packet length',
           'timing_only': 'Everything except timing (only timing kept)'}
    rows = []
    for g in ['all_12_features', 'no_timing_features', 'no_protocol_onehot',
              'no_link_layer_flags', 'no_length', 'timing_only']:
        v = SENS[g]
        dos = np.mean([r['per_type_detection']['DoS Attack'] for r in v['runs']]) * 100
        benign = np.mean([r['per_type_detection']['No Attack'] for r in v['runs']]) * 100
        nfeat = len(v['features_kept'])
        rows.append(f'| {lab[g]} | {nfeat} | {v["f1_mean"]*100:.2f} | {v["auc_mean"]:.4f} | '
                    f'{dos:.1f} | {benign:.1f} |')
    return rows


if __name__ == '__main__':
    e_t, e_ts = rows_for(ECU['time_ordered_80_20'])
    e_r, e_rs = rows_for(ECU['stratified_random_80_20'])
    i_r, i_s = rows_for(IOMT['provided_split_stratified_subsample'])
    t8 = '\n'.join(['**Table 8.** ECU-IoHT baseline comparison, time-ordered split (top) and stratified random split (bottom). Threshold for every unsupervised model is the 95th percentile of benign training scores. Mean over three seeds with range; ΔAUC is the test-set ROC-AUC difference from the VAE, averaged over seeds; the last column counts seeds whose paired bootstrap 95% interval (500 resamples) excludes zero.', '',
                    '*Time-ordered split*', '', HDR] + e_t + ['', '*Stratified random split*', '', HDR] + e_r)
    t9 = '\n'.join(['**Table 9.** CIC IoMT 2024 baseline comparison on the provided split, evaluated on a stratified 150,000-flow subsample of the 1.6 million-flow test set. Same threshold rule and paired bootstrap as Table 8.', '',
                    HDR] + i_r)
    t10 = '\n'.join(['**Table 10.** ECU-IoHT feature sensitivity: VAE with attention, time-ordered split, retrained after removing each feature group. Mean over three seeds. Benign pass is the fraction of benign packets not flagged. The timing-removed row has ROC-AUC 0.595 for seed 0 and 0.89 for seeds 1 and 2, so its mean is affected by one seed.', '',
                     '| Features removed | Features kept | F1 (%) | ROC-AUC | DoS detected (%) | Benign pass (%) |',
                     '|---|---|---|---|---|---|'] + sens_table())
    open('/home/claude/final/tables_v7.md', 'w').write(t8 + '\n\n' + t9 + '\n\n' + t10 + '\n')
    print(t8); print(); print(t9); print(); print(t10)
    print()
    print('ECU time  VAE auc', round(e_ts['VAE-attention (main)']['auc'], 4), 'IF', round(e_ts['Isolation Forest']['auc'], 4),
          'OCSVM', round(e_ts['One-Class SVM']['auc'], 4), 'AE', round(e_ts['AE-attention (deterministic, tuned)']['auc'], 4))
    print('ECU rand  VAE auc', round(e_rs['VAE-attention (main)']['auc'], 4), 'AE', round(e_rs['AE-attention (deterministic, tuned)']['auc'], 4))
    print('IoMT VAE F1/AUC', round(i_s['VAE-attention (main)']['f1'], 2), round(i_s['VAE-attention (main)']['auc'], 4),
          'OCSVM F1/AUC', round(i_s['One-Class SVM']['f1'], 2), round(i_s['One-Class SVM']['auc'], 4),
          'IF', round(i_s['Isolation Forest']['auc'], 4), 'AE', round(i_s['AE-attention (deterministic, tuned)']['auc'], 4))
