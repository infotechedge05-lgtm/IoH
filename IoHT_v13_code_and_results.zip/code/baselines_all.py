"""Unified baseline comparison for ECU-IoHT and CIC IoMT 2024.

Usage: python3 baselines_all.py ecu|iomt

Methods (all thresholds = 95th percentile of benign-TRAINING scores; no test labels used):
  VAE-attention (main)            H=32, L=8, beta=1, stochastic encoder   [pre-registered config]
  VAE-no-attention                H=32, L=8, beta=1, no attention layer
  VAE-attention (tuned)           H, L chosen on a benign-only validation split (label-free)
  AE-attention (deterministic)    beta=0, z=mu (no noise), H, L chosen on benign validation
  Isolation Forest                200 trees, fit on benign training rows
  One-Class SVM                   RBF, nu=0.05, fit on 10k benign training rows
  Random Forest (supervised)      uses labels; reference only

Bootstrap: B=500 resamples of the test set, the same resamples for every method (paired).
"""
import sys, json, time
import numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/ciciomt')
import vae_core as C
from sklearn.ensemble import IsolationForest, RandomForestClassifier
from sklearn.svm import OneClassSVM
from sklearn.metrics import roc_auc_score, f1_score
from sklearn.model_selection import train_test_split

DS = sys.argv[1]
SEEDS = [0, 1, 2]
B = 500
OUT = f'/home/claude/final/baselines_{DS}.json'
GRID = [(H, L) for H in (32, 64) for L in (4, 8, 16)]
T0 = time.time()

def log(*a):
    print(f'[{time.time()-T0:6.0f}s]', *a, flush=True)

# ---------------------------------------------------------------- data
def load_splits():
    """Return {split_name: (Xtr, ytr, Xte, yte)} with min-max scaling fitted on training rows."""
    if DS == 'ecu':
        sys.argv = ['x', '/mnt/user-data/uploads/608e8844-ECU_IoHT_1.xlsx', '/dev/null']
        sys.path.insert(0, '/home/claude/work')
        import vae_attn as A
        n, y, X = A.n, A.y, A.feat
        idx = np.arange(n)
        out = {}
        tr, te = idx[:int(.8 * n)], idx[int(.8 * n):]
        tr2, te2 = train_test_split(idx, test_size=0.2, stratify=y, random_state=0)
        for name, (a, b) in {'time_ordered_80_20': (tr, te),
                             'stratified_random_80_20': (np.sort(tr2), np.sort(te2))}.items():
            sc = A.fit_scale(X[a])
            out[name] = (sc(X[a]).astype(np.float32), y[a], sc(X[b]).astype(np.float32), y[b])
        return out

    def load_csv(path):
        xs, ls = [], []
        for ch in pd.read_csv(path, chunksize=1_000_000):
            ls.append(ch['label'].to_numpy(str))
            xs.append(ch.drop(columns=['label']).to_numpy(np.float32))
        return np.vstack(xs), np.concatenate(ls)
    Xtr, ltr = load_csv('/home/claude/ciciomt/data/train_iomt.csv')
    Xte, lte = load_csv('/home/claude/ciciomt/data/test_iomt.csv')
    lo, hi = Xtr.min(0), Xtr.max(0)
    span = np.where(hi - lo > 0, hi - lo, 1.0).astype(np.float32)
    sc = lambda Z: np.clip((Z - lo) / span, 0, 1).astype(np.float32)
    Xtr = sc(Xtr); Xte = sc(Xte)
    ytr = (ltr != 'benign').astype(int); yte_full = (lte != 'benign').astype(int)
    # stratified 150k test subsample (keeps every label's share); full test set is 1.6M rows
    sub, _ = train_test_split(np.arange(len(yte_full)), train_size=150_000, stratify=lte, random_state=0)
    log(f'IoMT train {Xtr.shape}, test subsample {len(sub)} of {len(yte_full)}')
    return {'provided_split_stratified_subsample': (Xtr, ytr, Xte[sub], yte_full[sub])}

# ---------------------------------------------------------------- training
EPOCHS = {'ecu': 40, 'iomt': 30}[DS]
BS = {'ecu': 256, 'iomt': 512}[DS]

def train(Xb, use_att, H, L, beta, det, seed):
    """Same loop as vae_core.train_vae; det=True sets the noise to zero (deterministic AE)."""
    rng = np.random.default_rng(seed)
    P = C.init_params(Xb.shape[1], H, L, rng, use_att)
    st, state = C.adam_init(P)
    for ep in range(EPOCHS):
        perm = rng.permutation(len(Xb))
        for i in range(0, len(Xb), BS):
            xb = Xb[perm[i:i + BS]]
            eps = np.zeros((len(xb), L)) if det else rng.standard_normal((len(xb), L))
            c = C.forward(P, xb, eps, use_att)
            g = C.backward(P, c, beta, use_att)
            state = C.adam_step(P, g, st, state, 1e-3)
    return P

def val_loss(P, Xv, use_att, beta):
    c = C.forward(P, Xv, np.zeros((len(Xv), P['Wmu'].shape[1])), use_att)
    rec, kl = C.per_sample_terms(c)
    return float(np.mean(rec + beta * kl))

def select_config(Xb, use_att, beta, det):
    """Choose (H, L) on a benign-only validation split. Never touches test rows or labels."""
    rs = np.random.default_rng(123)
    perm = rs.permutation(len(Xb)); nv = int(0.1 * len(Xb))
    Xv, Xt = Xb[perm[:nv]], Xb[perm[nv:]]
    rows = []
    for H, L in GRID:
        P = train(Xt, use_att, H, L, beta, det, seed=123)
        rows.append(dict(H=H, L=L, val_loss=val_loss(P, Xv, use_att, beta)))
        log(f'    grid H={H} L={L} val={rows[-1]["val_loss"]:.4f}')
    best = min(rows, key=lambda r: r['val_loss'])
    return best['H'], best['L'], rows

def score_ae(P, Xb, Xte, use_att):
    e_tr = C.recon_error(P, Xb, use_att)
    e_te = C.recon_error(P, Xte, use_att)
    thr = np.percentile(e_tr, 95)
    return e_te, (e_te > thr).astype(int)

# ---------------------------------------------------------------- evaluation
def bootstrap_summary(yt, methods):
    rng = np.random.default_rng(1000)
    n = len(yt)
    ref = methods['VAE-attention (main)'][0]
    f1b = {k: [] for k in methods}; aucb = {k: [] for k in methods}; dab = {k: [] for k in methods}
    for _ in range(B):
        b = rng.integers(0, n, n)
        yb = yt[b]
        ref_auc = roc_auc_score(yb, ref[b])
        for k, (s, p) in methods.items():
            f1b[k].append(f1_score(yb, p[b], zero_division=0))
            a = roc_auc_score(yb, s[b]); aucb[k].append(a); dab[k].append(ref_auc - a)
    rows = {}
    for k, (s, p) in methods.items():
        d = np.array(dab[k])
        rows[k] = dict(
            accuracy=float((p == yt).mean()),
            f1=float(f1_score(yt, p, zero_division=0)),
            roc_auc=float(roc_auc_score(yt, s)),
            f1_ci=[float(np.percentile(f1b[k], 2.5)), float(np.percentile(f1b[k], 97.5))],
            auc_ci=[float(np.percentile(aucb[k], 2.5)), float(np.percentile(aucb[k], 97.5))],
            benign_pass_rate=float((p[yt == 0] == 0).mean()),
            auc_diff_vs_VAE_attention=dict(
                point=float(roc_auc_score(yt, ref) - roc_auc_score(yt, s)),
                ci=[float(np.percentile(d, 2.5)), float(np.percentile(d, 97.5))]))
    return rows

def run_split(name, Xtr, ytr, Xte, yte, results_all):
    log(f'=== {DS} / {name}: train {len(ytr)} (benign {int((ytr==0).sum())}), test {len(yte)}')
    Xb = Xtr[ytr == 0]
    log('selecting VAE config on benign validation')
    Hv, Lv, grid_v = select_config(Xb, True, 1.0, False)
    log('selecting deterministic AE config on benign validation')
    Ha, La, grid_a = select_config(Xb, True, 0.0, True)
    log(f'  selected VAE-tuned H={Hv} L={Lv}; AE H={Ha} L={La}')
    per_seed = {}
    for seed in SEEDS:
        log(f'seed {seed}: training models')
        m = {}
        P = train(Xb, True, 32, 8, 1.0, False, seed)
        m['VAE-attention (main)'] = score_ae(P, Xb, Xte, True)
        P = train(Xb, False, 32, 8, 1.0, False, seed)
        m['VAE-no-attention'] = score_ae(P, Xb, Xte, False)
        P = train(Xb, True, Hv, Lv, 1.0, False, seed)
        m['VAE-attention (tuned)'] = score_ae(P, Xb, Xte, True)
        P = train(Xb, True, Ha, La, 0.0, True, seed)
        m['AE-attention (deterministic, tuned)'] = score_ae(P, Xb, Xte, True)
        iso = IsolationForest(n_estimators=200, random_state=seed).fit(Xb)
        thr_if = np.percentile(-iso.score_samples(Xb), 95)
        s_if = -iso.score_samples(Xte)
        m['Isolation Forest'] = (s_if, (s_if > thr_if).astype(int))
        rs = np.random.default_rng(seed)
        sub = Xb[rs.choice(len(Xb), min(10000, len(Xb)), replace=False)]
        svm = OneClassSVM(kernel='rbf', nu=0.05, gamma='scale').fit(sub)
        thr = np.percentile(-svm.decision_function(Xb), 95)
        s_te = -svm.decision_function(Xte)
        m['One-Class SVM'] = (s_te, (s_te > thr).astype(int))
        if len(ytr) > 300_000:
            sidx, _ = train_test_split(np.arange(len(ytr)), train_size=300_000, stratify=ytr, random_state=0)
        else:
            sidx = np.arange(len(ytr))
        rf = RandomForestClassifier(n_estimators=100, n_jobs=2, random_state=seed,
                                    class_weight='balanced').fit(Xtr[sidx], ytr[sidx])
        p = rf.predict_proba(Xte)[:, 1]
        m['Random Forest (supervised)'] = (p, (p > 0.5).astype(int))
        log(f'seed {seed}: bootstrap summary')
        per_seed[f'seed{seed}'] = bootstrap_summary(yte, m)
        for k in m:
            log(f'   {k:40s} AUC={per_seed[f"seed{seed}"][k]["roc_auc"]:.4f} '
                f'F1={per_seed[f"seed{seed}"][k]["f1"]:.4f}')
    results_all[name] = dict(selected_VAE_tuned=dict(H=Hv, L=Lv), selected_AE=dict(H=Ha, L=La),
                             validation_grid_VAE=grid_v, validation_grid_AE=grid_a,
                             per_seed=per_seed)
    json.dump(results_all, open(OUT, 'w'), indent=2, default=float)

def main():
    splits = load_splits()
    res = {'dataset': DS, 'epochs': EPOCHS, 'batch': BS, 'bootstrap': B,
           'note': 'thresholds: 95th pct of benign training scores; tuned configs chosen on benign validation only'}
    for name, (Xtr, ytr, Xte, yte) in splits.items():
        run_split(name, Xtr, ytr, Xte, yte, res)
    log('saved', OUT)

if __name__ == '__main__':
    main()
