import numpy as np
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, roc_auc_score, confusion_matrix)
# ---------------- VAE with feature attention ----------------
def sigmoid(z): return 1.0 / (1.0 + np.exp(-np.clip(z, -30, 30)))
def relu(z): return np.maximum(z, 0.0)
def softmax(E):
    E = E - E.max(1, keepdims=True); e = np.exp(E); return e / e.sum(1, keepdims=True)

def init_params(d, H, L, rng, use_att):
    xav = lambda a, b: rng.normal(0, np.sqrt(2.0 / (a + b)), (a, b))
    P = dict(W1=xav(d, H), b1=np.zeros(H), Wmu=xav(H, L), bmu=np.zeros(L),
             Wlv=0.1 * xav(H, L), blv=np.zeros(L), V1=xav(L, H), c1=np.zeros(H),
             V2=xav(H, d), c2=np.zeros(d))
    if use_att:
        P['Wa'] = rng.normal(0, 0.01, (d, d)); P['ba'] = np.zeros(d)
    return P

def forward(P, X, eps, use_att):
    B, d_ = X.shape
    if use_att:
        A = softmax(X @ P['Wa'] + P['ba'])          # per-sample feature attention
        Xs = X * (d_ * A)                            # rescaled so mean weight = 1
    else:
        A = None; Xs = X
    H1pre = Xs @ P['W1'] + P['b1']; H1 = relu(H1pre)
    mu = H1 @ P['Wmu'] + P['bmu']
    lv = np.clip(H1 @ P['Wlv'] + P['blv'], -8, 8)
    Z = mu + np.exp(0.5 * lv) * eps
    G1pre = Z @ P['V1'] + P['c1']; G1 = relu(G1pre)
    xh = sigmoid(G1 @ P['V2'] + P['c2'])
    return dict(X=X, A=A, Xs=Xs, H1pre=H1pre, H1=H1, mu=mu, lv=lv, eps=eps,
                Z=Z, G1pre=G1pre, G1=G1, xh=xh)

def per_sample_terms(c):
    X, xh = c['X'], c['xh']
    rec = -(X * np.log(xh + 1e-7) + (1 - X) * np.log(1 - xh + 1e-7)).sum(1)
    kl = -0.5 * (1 + c['lv'] - c['mu'] ** 2 - np.exp(c['lv'])).sum(1)
    return rec, kl

def backward(P, c, beta, use_att):
    X = c['X']; B, d_ = X.shape
    g = {}
    dlogit = (c['xh'] - X) / B
    g['V2'] = c['G1'].T @ dlogit; g['c2'] = dlogit.sum(0)
    dG1pre = (dlogit @ P['V2'].T) * (c['G1pre'] > 0)
    g['V1'] = c['Z'].T @ dG1pre; g['c1'] = dG1pre.sum(0)
    dZ = dG1pre @ P['V1'].T
    mu, lv, eps = c['mu'], c['lv'], c['eps']
    dmu = dZ + beta * mu / B
    dlv = dZ * eps * 0.5 * np.exp(0.5 * lv) + beta * (-0.5 * (1 - np.exp(lv))) / B
    g['Wmu'] = c['H1'].T @ dmu; g['bmu'] = dmu.sum(0)
    g['Wlv'] = c['H1'].T @ dlv; g['blv'] = dlv.sum(0)
    dH1pre = (dmu @ P['Wmu'].T + dlv @ P['Wlv'].T) * (c['H1pre'] > 0)
    g['W1'] = c['Xs'].T @ dH1pre; g['b1'] = dH1pre.sum(0)
    if use_att:
        dXs = dH1pre @ P['W1'].T
        dA = dXs * X * d_
        dE = c['A'] * (dA - (dA * c['A']).sum(1, keepdims=True))   # softmax backward
        g['Wa'] = X.T @ dE; g['ba'] = dE.sum(0)
    return g

def adam_init(P):
    return {k: [np.zeros_like(v), np.zeros_like(v)] for k, v in P.items()}, 0

def adam_step(P, g, st, state, lr, b1=0.9, b2=0.999, e=1e-8):
    t_ = state + 1
    for k in P:
        m, v = st[k]
        m[:] = b1 * m + (1 - b1) * g[k]
        v[:] = b2 * v + (1 - b2) * g[k] ** 2
        mh = m / (1 - b1 ** t_); vh = v / (1 - b2 ** t_)
        P[k] -= lr * mh / (np.sqrt(vh) + e)
    return t_

def train_vae(Xb, use_att, H=32, L=8, beta=1.0, epochs=40, bs=256, lr=1e-3, seed=0, hist=None):
    rng = np.random.default_rng(seed)
    P = init_params(Xb.shape[1], H, L, rng, use_att)
    st, state = adam_init(P)
    for ep in range(epochs):
        perm = rng.permutation(len(Xb)); tot = 0.0
        for i in range(0, len(Xb), bs):
            xb = Xb[perm[i:i + bs]]
            eps = rng.standard_normal((len(xb), L))
            c = forward(P, xb, eps, use_att)
            rec, kl = per_sample_terms(c)
            tot += (rec + beta * kl).sum()
            g = backward(P, c, beta, use_att)
            state = adam_step(P, g, st, state, lr)
        if hist is not None:
            hist.append(tot / len(Xb))
        if ep % 10 == 0 or ep == epochs - 1:
            print(f'  epoch {ep:3d}  mean -ELBO {tot / len(Xb):.4f}', flush=True)
    return P

def recon_error(P, X, use_att):
    # deterministic: z = mu (eps = 0)
    c = forward(P, X, np.zeros((len(X), P['Wmu'].shape[1])), use_att)
    rec, _ = per_sample_terms(c)
    return rec

# ---------------- evaluation ----------------
def binary_metrics(ytrue, ypred, score=None):
    m = dict(accuracy=accuracy_score(ytrue, ypred),
             precision=precision_score(ytrue, ypred, zero_division=0),
             recall=recall_score(ytrue, ypred, zero_division=0),
             f1=f1_score(ytrue, ypred, zero_division=0))
    if score is not None:
        m['roc_auc'] = roc_auc_score(ytrue, score)
    m['confusion_matrix'] = confusion_matrix(ytrue, ypred).tolist()
    return m

def per_type_recall(ytest_type, ypred):
    out = {}
    for a in np.unique(ytest_type):
        if a == 'No Attack':
            out[a] = float(np.mean(ypred[ytest_type == a] == 0))  # specificity
        else:
            out[a] = float(np.mean(ypred[ytest_type == a] == 1))  # detection rate
    return out

