"""Supervised deep baseline: multilayer perceptron (scikit-learn, Adam, early stopping).
Usage: python3 mlp_baseline.py ecu|iomt|wustl|wustl_net
Same splits, scaling and test sets as baselines_all.py / baselines_wustl.py.
Three seeds; threshold 0.5 on predicted attack probability (same convention as the Random Forest)."""
import sys, json, time
DS = sys.argv[1]
import numpy as np
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import roc_auc_score, f1_score

if DS in ('ecu', 'iomt'):
    sys.argv = ['x', DS]
    sys.path.insert(0, '/home/claude/final')
    import baselines_all as M
else:
    sys.argv = ['x', DS]
    sys.path.insert(0, '/home/claude/wustl/code')
    import baselines_wustl as M

T0 = time.time()
def log(*a): print(f'[{time.time()-T0:6.0f}s]', *a, flush=True)
SEEDS = [0, 1, 2]
B = 200
OUT = f'/home/claude/final/mlp_{DS}.json'

splits = M.load_splits()
res = {'model': 'MLP (64,32), Adam, early stopping', 'dataset': DS, 'splits': {}}
for name, (Xtr, ytr, Xte, yte) in splits.items():
    if len(ytr) > 300_000:                      # same 300k stratified subsample as the Random Forest
        from sklearn.model_selection import train_test_split
        idx, _ = train_test_split(np.arange(len(ytr)), train_size=300_000, stratify=ytr, random_state=0)
        Xtr, ytr = Xtr[idx], ytr[idx]
    per = {}
    for seed in SEEDS:
        clf = MLPClassifier(hidden_layer_sizes=(64, 32), activation='relu', solver='adam',
                            learning_rate_init=1e-3, batch_size=256, max_iter=200,
                            early_stopping=True, validation_fraction=0.1, n_iter_no_change=10,
                            random_state=seed)
        clf.fit(Xtr, ytr)
        p = clf.predict_proba(Xte)[:, 1]
        pred = (p > 0.5).astype(int)
        rng = np.random.default_rng(1000 + seed)
        aucs, f1s = [], []
        for _ in range(B):
            b = rng.integers(0, len(yte), len(yte))
            aucs.append(roc_auc_score(yte[b], p[b])); f1s.append(f1_score(yte[b], pred[b], zero_division=0))
        per[f'seed{seed}'] = dict(
            accuracy=float((pred == yte).mean()), f1=float(f1_score(yte, pred, zero_division=0)),
            roc_auc=float(roc_auc_score(yte, p)),
            auc_ci=[float(np.percentile(aucs, 2.5)), float(np.percentile(aucs, 97.5))],
            f1_ci=[float(np.percentile(f1s, 2.5)), float(np.percentile(f1s, 97.5))],
            iterations=int(clf.n_iter_))
        log(f'{name} seed {seed}: acc={per[f"seed{seed}"]["accuracy"]:.4f} '
            f'F1={per[f"seed{seed}"]["f1"]:.4f} AUC={per[f"seed{seed}"]["roc_auc"]:.4f}')
    res['splits'][name] = per
    json.dump(res, open(OUT, 'w'), indent=2)
log('saved', OUT)
