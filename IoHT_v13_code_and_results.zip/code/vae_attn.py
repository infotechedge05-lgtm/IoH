"""VAE + feature attention for ECU-IoHT packet data (NumPy, manual backprop)."""
import sys, json
import numpy as np, pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, roc_auc_score, confusion_matrix)
from sklearn.ensemble import RandomForestClassifier

IN = sys.argv[1]
OUT = sys.argv[2]

# ---------------- features (no IPs, no Info text, no labels) ----------------
df = pd.read_excel(IN).sort_values('No.').reset_index(drop=True)
assert df['Time'].is_monotonic_increasing
y = (df['Type'] == 'Attack').astype(int).to_numpy()
atype = df['Type of attack'].to_numpy()
t = df['Time'].to_numpy(float)
n = len(df)

dt = np.maximum(np.diff(t, prepend=t[0]), 0.0)          # inter-arrival time
lo = np.searchsorted(t, t - 1.0, side='right')           # causal 1-second window
cs_all = np.concatenate([[0], np.cumsum(np.ones(n))])
cnt1 = (np.arange(n) + 1) - lo                            # packets in past 1 s
is_icmp = (df['Protocol'] == 'ICMP').to_numpy(float)
cs_icmp = np.concatenate([[0], np.cumsum(is_icmp)])
icmp1 = cs_icmp[np.arange(n) + 1] - cs_icmp[lo]           # ICMP packets in past 1 s

protos = ['ICMP', 'TCP', 'TLSv1.2', 'ARP', 'DNS']
proto_oh = np.stack([(df['Protocol'] == p).to_numpy(float) for p in protos]
                    + [(~df['Protocol'].isin(protos)).to_numpy(float)], 1)
feat = np.column_stack([
    np.log1p(df['Length'].to_numpy(float)),
    proto_oh,
    np.log1p(dt),
    np.log1p(cnt1.astype(float)),
    np.log1p(icmp1),
    df['Destination'].str.lower().eq('broadcast').to_numpy(float),
    df['Source'].str.contains(':').to_numpy(float),           # MAC-layer source
])
FEAT_NAMES = ['log_len'] + [f'proto_{p}' for p in protos] + ['proto_other',
             'log_dt', 'log_cnt_1s', 'log_icmp_1s', 'dst_broadcast', 'src_is_mac']
d = feat.shape[1]

def fit_scale(Xtr):
    lo_, hi_ = Xtr.min(0), Xtr.max(0)
    span = np.where(hi_ - lo_ > 0, hi_ - lo_, 1.0)
    return lambda X: np.clip((X - lo_) / span, 0.0, 1.0)

# ---------------- VAE with feature attention ----------------
def sigmoid(z): return 1.0 / (1.0 + np.exp(-np.clip(z, -30, 30)))
def relu(z): return np.maximum(z, 0.0)
def softmax(E):
    E = E - E.max(1, keepdims=True); e = np.exp(E); return e / e.sum(1, keepdims=True)

def init_params(d, H, L, rng, use_att):
    xav = lambda a, b: rng.normal(0, np.sqrt(2.0 / (a + b)), (a, b))
    P = dict(W1=xav(d, H), b1=np.zeros(H), Wmu=xav(H, L), bmu=np.zeros(L),
             Wlv=0.1 * xav(H, L), blv=np.zeros(L), V1=xav(L, H), c1=np.zeros(H),
             V2=xav(H, d), c2=np.zeros(d))
    if use_att:
        P['Wa'] = rng.normal(0, 0.01, (d, d)); P['ba'] = np.zeros(d)
    return P

def forward(P, X, eps, use_att):
    B, d_ = X.shape
    if use_att:
        A = softmax(X @ P['Wa'] + P['ba'])          # per-sample feature attention
        Xs = X * (d_ * A)                            # rescaled so mean weight = 1
    else:
        A = None; Xs = X
    H1pre = Xs @ P['W1'] + P['b1']; H1 = relu(H1pre)
    mu = H1 @ P['Wmu'] + P['bmu']
    lv = np.clip(H1 @ P['Wlv'] + P['blv'], -8, 8)
    Z = mu + np.exp(0.5 * lv) * eps
    G1pre = Z @ P['V1'] + P['c1']; G1 = relu(G1pre)
    xh = sigmoid(G1 @ P['V2'] + P['c2'])
    return dict(X=X, A=A, Xs=Xs, H1pre=H1pre, H1=H1, mu=mu, lv=lv, eps=eps,
                Z=Z, G1pre=G1pre, G1=G1, xh=xh)

def per_sample_terms(c):
    X, xh = c['X'], c['xh']
    rec = -(X * np.log(xh + 1e-7) + (1 - X) * np.log(1 - xh + 1e-7)).sum(1)
    kl = -0.5 * (1 + c['lv'] - c['mu'] ** 2 - np.exp(c['lv'])).sum(1)
    return rec, kl

def backward(P, c, beta, use_att):
    X = c['X']; B, d_ = X.shape
    g = {}
    dlogit = (c['xh'] - X) / B
    g['V2'] = c['G1'].T @ dlogit; g['c2'] = dlogit.sum(0)
    dG1pre = (dlogit @ P['V2'].T) * (c['G1pre'] > 0)
    g['V1'] = c['Z'].T @ dG1pre; g['c1'] = dG1pre.sum(0)
    dZ = dG1pre @ P['V1'].T
    mu, lv, eps = c['mu'], c['lv'], c['eps']
    dmu = dZ + beta * mu / B
    dlv = dZ * eps * 0.5 * np.exp(0.5 * lv) + beta * (-0.5 * (1 - np.exp(lv))) / B
    g['Wmu'] = c['H1'].T @ dmu; g['bmu'] = dmu.sum(0)
    g['Wlv'] = c['H1'].T @ dlv; g['blv'] = dlv.sum(0)
    dH1pre = (dmu @ P['Wmu'].T + dlv @ P['Wlv'].T) * (c['H1pre'] > 0)
    g['W1'] = c['Xs'].T @ dH1pre; g['b1'] = dH1pre.sum(0)
    if use_att:
        dXs = dH1pre @ P['W1'].T
        dA = dXs * X * d_
        dE = c['A'] * (dA - (dA * c['A']).sum(1, keepdims=True))   # softmax backward
        g['Wa'] = X.T @ dE; g['ba'] = dE.sum(0)
    return g

def adam_init(P):
    return {k: [np.zeros_like(v), np.zeros_like(v)] for k, v in P.items()}, 0

def adam_step(P, g, st, state, lr, b1=0.9, b2=0.999, e=1e-8):
    t_ = state + 1
    for k in P:
        m, v = st[k]
        m[:] = b1 * m + (1 - b1) * g[k]
        v[:] = b2 * v + (1 - b2) * g[k] ** 2
        mh = m / (1 - b1 ** t_); vh = v / (1 - b2 ** t_)
        P[k] -= lr * mh / (np.sqrt(vh) + e)
    return t_

def train_vae(Xb, use_att, H=32, L=8, beta=1.0, epochs=40, bs=256, lr=1e-3, seed=0):
    rng = np.random.default_rng(seed)
    P = init_params(Xb.shape[1], H, L, rng, use_att)
    st, state = adam_init(P)
    for ep in range(epochs):
        perm = rng.permutation(len(Xb)); tot = 0.0
        for i in range(0, len(Xb), bs):
            xb = Xb[perm[i:i + bs]]
            eps = rng.standard_normal((len(xb), L))
            c = forward(P, xb, eps, use_att)
            rec, kl = per_sample_terms(c)
            tot += (rec + beta * kl).sum()
            g = backward(P, c, beta, use_att)
            state = adam_step(P, g, st, state, lr)
        if ep % 10 == 0 or ep == epochs - 1:
            print(f'  epoch {ep:3d}  mean -ELBO {tot / len(Xb):.4f}', flush=True)
    return P

def recon_error(P, X, use_att):
    # deterministic: z = mu (eps = 0)
    c = forward(P, X, np.zeros((len(X), P['Wmu'].shape[1])), use_att)
    rec, _ = per_sample_terms(c)
    return rec

# ---------------- gradient check (before trusting any result) ----------------
def gradcheck():
    rng = np.random.default_rng(1)
    for use_att in [True, False]:
        P = init_params(5, 4, 3, rng, use_att)
        X = rng.uniform(0, 1, (6, 5)); eps = rng.standard_normal((6, 3)); beta = 0.7
        def loss(P_):
            c = forward(P_, X, eps, use_att); r, k = per_sample_terms(c)
            return (r + beta * k).mean()
        G = backward(P, forward(P, X, eps, use_att), beta, use_att)
        worst = 0.0
        for k in P:
            flat = P[k].reshape(-1)
            for j in rng.choice(flat.size, min(6, flat.size), replace=False):
                old = flat[j]; h = 1e-5
                flat[j] = old + h; lp = loss(P)
                flat[j] = old - h; lm = loss(P)
                flat[j] = old
                num = (lp - lm) / (2 * h)
                ana = G[k].reshape(-1)[j]
                worst = max(worst, abs(num - ana) / max(1e-8, abs(num) + abs(ana)))
        print(f'gradcheck use_att={use_att}: max relative error {worst:.2e}', flush=True)
        assert worst < 1e-4, 'gradient check failed'

# ---------------- evaluation ----------------
def binary_metrics(ytrue, ypred, score=None):
    m = dict(accuracy=accuracy_score(ytrue, ypred),
             precision=precision_score(ytrue, ypred, zero_division=0),
             recall=recall_score(ytrue, ypred, zero_division=0),
             f1=f1_score(ytrue, ypred, zero_division=0))
    if score is not None:
        m['roc_auc'] = roc_auc_score(ytrue, score)
    m['confusion_matrix'] = confusion_matrix(ytrue, ypred).tolist()
    return m

def per_type_recall(ytest_type, ypred):
    out = {}
    for a in np.unique(ytest_type):
        if a == 'No Attack':
            out[a] = float(np.mean(ypred[ytest_type == a] == 0))  # specificity
        else:
            out[a] = float(np.mean(ypred[ytest_type == a] == 1))  # detection rate
    return out

def run_split(name, tr_idx, te_idx):
    print(f'\n=== split: {name}  train={len(tr_idx)} test={len(te_idx)} ===', flush=True)
    scale = fit_scale(feat[tr_idx])
    Xtr = scale(feat[tr_idx]); Xte = scale(feat[te_idx])
    ytr, yte = y[tr_idx], y[te_idx]
    tte = atype[te_idx]
    benign_tr = Xtr[ytr == 0]
    res = dict(split=name, n_train=int(len(tr_idx)), n_test=int(len(te_idx)),
               test_attack_share=float(yte.mean()))
    res['majority_baseline_accuracy'] = float(max(yte.mean(), 1 - yte.mean()))

    # threshold = 95th percentile of reconstruction error on benign TRAINING traffic (label-free at test time)
    for use_att, key in [(True, 'vae_attention'), (False, 'vae_no_attention')]:
        print(f'-- training {key} on benign training traffic ({len(benign_tr)} rows)', flush=True)
        P = train_vae(benign_tr, use_att)
        e_tr = recon_error(P, benign_tr, use_att)
        thr = np.percentile(e_tr, 95)
        e_te = recon_error(P, Xte, use_att)
        pred = (e_te > thr).astype(int)
        m = binary_metrics(yte, pred, score=e_te)
        m['threshold_95pct_benign_train'] = float(thr)
        m['per_type_detection'] = per_type_recall(tte, pred)
        res[key] = m
        print(f'   {key}: acc={m["accuracy"]:.4f} P={m["precision"]:.4f} '
              f'R={m["recall"]:.4f} F1={m["f1"]:.4f} AUC={m["roc_auc"]:.4f}', flush=True)

    # supervised reference: Random Forest on all training rows (uses labels)
    rf = RandomForestClassifier(n_estimators=100, n_jobs=2, random_state=0, class_weight='balanced')
    rf.fit(Xtr, ytr)
    p_rf = rf.predict_proba(Xte)[:, 1]
    m = binary_metrics(yte, (p_rf > 0.5).astype(int), score=p_rf)
    m['per_type_detection'] = per_type_recall(tte, (p_rf > 0.5).astype(int))
    res['random_forest_supervised'] = m
    print(f'   random_forest: acc={m["accuracy"]:.4f} P={m["precision"]:.4f} '
          f'R={m["recall"]:.4f} F1={m["f1"]:.4f} AUC={m["roc_auc"]:.4f}', flush=True)
    return res

if __name__ == '__main__':
    print(f'rows={n} features={d}: {FEAT_NAMES}', flush=True)
    gradcheck()
    idx = np.arange(n)
    tr_t = idx[: int(0.8 * n)]; te_t = idx[int(0.8 * n):]
    tr_r, te_r = train_test_split(idx, test_size=0.2, stratify=y, random_state=0)
    results = [run_split('time_ordered_80_20', tr_t, te_t),
               run_split('stratified_random_80_20', np.sort(tr_r), np.sort(te_r))]
    with open(OUT, 'w') as f:
        json.dump(dict(features=FEAT_NAMES, results=results), f, indent=2, default=float)
    print('\nsaved', OUT)
